#include <stdio.h>
#include "tad.h"

int main(int argc, char const *argv[]) {

  int placa = 0;
  int hora = 0;
  int hEstacionado = 0;

  estacionamento *e1, *e2;
  e1 = criarEstacionamento1();
  e2 = criarEstacionamento2();

  int op = 0;
  do {
    printf("1-Registrar Carro\n2-Imprimir Carros\n3-Sair\n");
    scanf("%d", &op);

    switch (op) {
      case 1:
      printf("Insira a placa do carro:\n");
      scanf("%d", &placa);
      printf("Insira a hora de chegada:\n");
      scanf("%d", &hora);
      printf("Insira quanto tempo ficará:\n");
      scanf("%d", &hEstacionado);

      checkIn(placa, hora, hEstacionado, e1, e2);
      break;

      case 2:
      printf("=====CARROS NO ESTACIONAMENTO 1====\n");
      imprimirCarros(e1);
      printf("=====CARROS NO ESTACIONAMENTO 2====\n");
      imprimirCarros(e2);
      break;

      case 3:
      return 0;
      break;

      default:
      printf("Escolha uma das 3 opções\n");
      break;
    }
  } while(1);
  return 0;
}
