#include <stdlib.h>
#include <stdio.h>
#include "tad.h"

#define max1 100
#define max2 100

struct Carro {
  int placa;
  int hora;
  int hEstacionado;
};

struct Estacionamento {
  carro* vaga;
  int nCarros;
};

//Dois estacionamentos podem ter quantidade de vagas diferentes, portanto criamos separadamente para facilitar o entendimento
estacionamento* criarEstacionamento1(){
  estacionamento *e1 = (estacionamento*) malloc(sizeof(estacionamento));
  e1->vaga = (carro*) malloc(sizeof(carro)*max1);
  e1->nCarros = 0;
  return e1;
}

estacionamento* criarEstacionamento2(){
  estacionamento *e2 = (estacionamento*) malloc(sizeof(estacionamento));
  e2->vaga = (carro*) malloc(sizeof(carro)*max2);
  e2->nCarros = 0;
  return e2;
}

void checkOut(estacionamento *e, int hora, int est){
  if (est == 1) {//Se for o estacionamento 1 ele funciona como pilha(LIFO)
    for (int i = e->nCarros-1; i >= 0; i--) {//Começando do topo ao último
      if(hora >= e->vaga[i].hora+e->vaga[i].hEstacionado){//Se a hr de sáida for menor ou igual a atual
        printf("O carro: %d - %f será retirado\n", e->vaga[i].placa, (float)(e->vaga[i].hEstacionado*3));
        e->nCarros = e->nCarros-1;//Finge que tem n a menos, assim é como se o carro saisse e liberasse a vaga
      } else break;//Se achar um que seja maior quer dizer que todos dali pra dentro também são, portanto sai do loop
    }
  } else if (est == 2) {//Se for o estacionamento 2 ele funciona como uma fila(FIFO)
    int cont = 0;
    for (int i = 0; i < e->nCarros; i++) {//Começando do inicio da fila
      if(hora >= e->vaga[i].hora+e->vaga[i].hEstacionado){//Se a hr de saida for menor ou igual a atual
        printf("O carro: %d - %f será retirado\n", e->vaga[i].placa, (float)(e->vaga[i].hEstacionado*3));
        e->nCarros = e->nCarros-1;//menos 1
        cont++;//conta quantos são menores e devem sair
      } else break;//Assim que achar um que seja maior todos dali pra trás são menores, sai do loop
    }
    for (int i = 0; i < e->nCarros-cont; i++) {
      e->vaga[i] = e->vaga[i+cont];//Shift na fila
    }
  }
}

carro* sorteio(estacionamento *e1, estacionamento *e2){
  estacionamento *e = (estacionamento*) malloc(sizeof(estacionamento));
  e->vaga = (carro*) malloc(sizeof(carro)*(e1->nCarros + e2->nCarros));
  e->nCarros = 0;

  for (int i = 0; i < e1->nCarros; i++) {
    e->vaga[i] = e1->vaga[i];
    e->nCarros = e->nCarros+1;
  }

  for (int i = 0; i < e2->nCarros; i++) {
    e->vaga[i+e1->nCarros] = e2->vaga[i];
    e->nCarros = e->nCarros+1;
  }

  int x = rand() % (e1->nCarros + e2->nCarros);
  printf("%d - %0.2f\n", e->vaga[x].placa, (float)(e->vaga[x].hEstacionado*3*0.9));
}

int checkIn(int placa, int hora, int hEstacionado, estacionamento *e1, estacionamento *e2){
  if(placa/1000 >= 10) {//Se a placa tiver mais que 4 digitos
      printf("Placa inválida\n");
      return 0;
  } else if(hora < 8 || hora > 22) {//Se a hr de chegada estiver fora do expediente ou não existir
    printf("hora de chegada inválida\n");
    return 0;
  } else if(hEstacionado+hora < 8 || hora+hEstacionado > 22) {//Se a hr de saida estiver fora do expediente, considerando que um carro não dorme no estacionamento
    printf("hora de saída inválida\n");
    return 0;
  }

  carro carro;
  carro.placa = placa;
  carro.hora = hora;
  carro.hEstacionado = hEstacionado;

  if (e1->nCarros == 0 && e2->nCarros == 0){
    if((hora == 9 || hora == 12 || hora == 15 || hora == 18) && (e1->nCarros+e2->nCarros >= 50)) sorteio(e1, e2);
    e1->vaga[0] = carro;
    e1->nCarros = 1;
  } else if(e1->nCarros != 0 && e2->nCarros == 0){
    checkOut(e1, hora, 1);
    if((hora == 9 || hora == 12 || hora == 15 || hora == 18) && (e1->nCarros+e2->nCarros >= 50)) sorteio(e1, e2);
    e2->vaga[0] = carro;
    e2->nCarros = 1;
  } else if(e2->nCarros != 0 && e1->nCarros == 0){
    checkOut(e2, hora, 2);
    if((hora == 9 || hora == 12 || hora == 15 || hora == 18) && (e1->nCarros+e2->nCarros >= 50)) sorteio(e1, e2);
    e1->vaga[0] = carro;
    e1->nCarros = 1;
  } else if((e1->vaga[e1->nCarros-1].hora + e1->vaga[e1->nCarros-1].hEstacionado) >= (carro.hora + carro.hEstacionado) && e1->nCarros < max1) {
    checkOut(e1, hora, 1);
    checkOut(e2, hora, 2);
    if((hora == 9 || hora == 12 || hora == 15 || hora == 18) && (e1->nCarros+e2->nCarros >= 50)) sorteio(e1, e2);
    e1->vaga[e1->nCarros] = carro;
    e1->nCarros = e1->nCarros+1;
  } else if ((e2->vaga[e2->nCarros-1].hora + e2->vaga[e2->nCarros-1].hEstacionado) <= (carro.hora + carro.hEstacionado) && e2->nCarros < max2) {
    checkOut(e1, hora, 1);
    checkOut(e2, hora, 2);
    if((hora == 9 || hora == 12 || hora == 15 || hora == 18) && (e1->nCarros+e2->nCarros >= 50)) sorteio(e1, e2);
    e2->vaga[e2->nCarros] = carro;
    e2->nCarros = e2->nCarros+1;
  } else {
    printf("O carro não se encaixa nos requisitos\n");
  }
}

void imprimirCarros(estacionamento *e){
  for (int i = 0; i < e->nCarros; i++) {
    printf("%d - %0.2f\n", e->vaga[i].placa, (float)(e->vaga[i].hEstacionado*3));
  }
}
