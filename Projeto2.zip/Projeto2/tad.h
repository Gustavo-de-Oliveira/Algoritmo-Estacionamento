typedef struct Carro carro;
typedef struct Estacionamento estacionamento;

estacionamento* criarEstacionamento1();
estacionamento* criarEstacionamento2();
int checkIn(int placa, int hora, int hEstacionado, estacionamento *e1, estacionamento *e2);
void imprimirCarros(estacionamento *e);
//carro* sorteio(estacionamento *e1, estacionamento *e2);
